package com.luizfernando.ia;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.net.Uri;
import android.view.ViewGroup;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Button;
import android.graphics.Color;

public class MainActivity extends Activity {
    public static final String EXTRA_SCREEN_TEXT="screen_text_for_user_review";
    private static final String APP_URL="https://contactokakashigamesofc24-dotcom.github.io/ia-de-luiz-fernando/";
    private WebView webView; private PermissionRequest pendingRequest;
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(16,19,34));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);setContentView(root);
        LinearLayout actions=new LinearLayout(this);actions.setBackgroundColor(Color.rgb(25,29,48));
        Button useKeyboard=new Button(this);useKeyboard.setText("Ativar/selecionar TecladoIA");useKeyboard.setAllCaps(false);actions.addView(useKeyboard,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        Button accessibility=new Button(this);accessibility.setText("Acessibilidade (opcional)");accessibility.setAllCaps(false);actions.addView(accessibility,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));root.addView(actions);
        useKeyboard.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Usar TecladoIA").setMessage("O Android abrirá o seletor de teclado. Selecione TecladoIA. O teclado processa os toques localmente e não registra o texto digitado.").setNegativeButton("Cancelar",null).setPositiveButton("Abrir seletor",(d,w)->{((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker();}).show());
        accessibility.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Acessibilidade opcional").setMessage("Só é necessária para a função “Analisar tela”. Não é necessária para digitar. Quando ativada, a tela só será lida após você tocar em Analisar tela e confirmar; antes de enviar o texto ao Gemini, você poderá revisar. Ativar? ").setNegativeButton("Agora não",null).setPositiveButton("Continuar",(d,w)->startActivity(new android.content.Intent(this,AccessibilitySetupActivity.class))).show());
        webView=new WebView(this);root.addView(webView,new LinearLayout.LayoutParams(-1,0,1));WebSettings settings=webView.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setMediaPlaybackRequiresUserGesture(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest req){runOnUiThread(()->{String host=req.getOrigin().getHost();boolean trusted="contactokakashigamesofc24-dotcom.github.io".equals(host);boolean audio=false;for(String x:req.getResources())if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x))audio=true;if(!trusted||!audio){req.deny();return;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});else{pendingRequest=req;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},40);}});}});
        if(state==null)webView.loadUrl(APP_URL);else webView.restoreState(state);
        String screenText=getIntent().getStringExtra(EXTRA_SCREEN_TEXT);if(screenText!=null&&!screenText.isBlank())showReview(screenText);
    }
    private void showReview(String text){new AlertDialog.Builder(this).setTitle("Revisar texto capturado").setMessage("O texto abaixo foi lido da tela após sua confirmação. Ele só será enviado ao Gemini se você tocar em “Enviar ao Gemini”.\n\n"+text).setNegativeButton("Descartar",(d,w)->{}).setPositiveButton("Enviar ao Gemini",(d,w)->{String js="(function(){const t="+org.json.JSONObject.quote("Analise este texto capturado da tela e me ajude: "+text)+";const i=document.querySelector('#input'); if(i){i.value=t;i.dispatchEvent(new Event('input',{bubbles:true}));document.querySelector('#form').requestSubmit();}})();";webView.evaluateJavascript(js,null);}).show();}
    @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);setIntent(intent);String t=intent.getStringExtra(EXTRA_SCREEN_TEXT);if(t!=null&&!t.isBlank())showReview(t);}
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==40&&pendingRequest!=null){if(r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)pendingRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});else pendingRequest.deny();pendingRequest=null;}}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(webView!=null)webView.saveState(out);}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
