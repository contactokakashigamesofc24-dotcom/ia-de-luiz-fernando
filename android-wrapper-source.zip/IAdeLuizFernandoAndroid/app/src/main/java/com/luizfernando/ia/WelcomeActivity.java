package com.luizfernando.ia;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class WelcomeActivity extends Activity {
    private final int bg=Color.rgb(16,19,34), card=Color.rgb(28,33,52), text=Color.rgb(244,246,255), muted=Color.rgb(173,182,207), blue=Color.rgb(61,125,255), green=Color.rgb(89,214,177);
    private LinearLayout root, rows;
    private TextView accessibilityState,micState,notificationState,batteryState;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String title){Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setPadding(dp(12),0,dp(12),0);b.setMinHeight(dp(43));b.setBackground(shape(blue,14));return b;}

    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);buildScreen();refreshStatuses();}
    private void buildScreen(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(22),dp(22),dp(22),dp(22));root.setBackgroundColor(bg);scroll.addView(root);setContentView(scroll);
        TextView emblem=label("✦  ✧  ✦",30,Color.WHITE);emblem.setGravity(Gravity.CENTER);emblem.setTypeface(null,Typeface.BOLD);emblem.setBackground(shape(blue,100));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(88),dp(88));ep.topMargin=dp(18);root.addView(emblem,ep);
        TextView welcome=label("Bem vindo ao TecladoIA",25,text);welcome.setTypeface(null,Typeface.BOLD);welcome.setGravity(Gravity.CENTER);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);wp.topMargin=dp(22);root.addView(welcome,wp);
        TextView intro=label("Antes de começar, autorize o que o app usa. Você pode mudar tudo depois em definições > permissões.",14,muted);intro.setGravity(Gravity.CENTER);intro.setLineSpacing(dp(3),1.0f);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(9);ip.bottomMargin=dp(22);root.addView(intro,ip);
        rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);root.addView(rows,new LinearLayout.LayoutParams(-1,-2));
        accessibilityState=addPermissionRow("Acessibilidade","Opcional: só para analisar o texto visível da tela após sua confirmação. Não é necessária para o teclado aparecer.","Ativar",this::openAccessibility);
        micState=addPermissionRow("Microfone","Usado somente enquanto você mantém o ditado por voz aberto.","Permitir",this::requestMic);
        notificationState=addPermissionRow("Notificações","Opcional: avisos sobre novas versões.","Permitir",this::requestNotifications);
        batteryState=addPermissionRow("Bateria sem restrições","Opcional: pode ajudar a manter funções em segundo plano. O teclado básico funciona sem isso.","Gerenciar",this::manageBattery);
        TextView perms=label("✓  Permissões",12,muted);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=dp(14);root.addView(perms,pp);
        Button go=button("✓  Continuar");go.setTextSize(16);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(54));gp.topMargin=dp(12);root.addView(go,gp);go.setOnClickListener(v->{getSharedPreferences("keyboard_setup",MODE_PRIVATE).edit().putBoolean("welcomed",true).apply();startActivity(new Intent(this,MainActivity.class));finish();});
        TextView privacy=label("Você decide quais permissões conceder. A análise de tela permanece opcional e pede confirmação antes de capturar texto.",11,muted);privacy.setGravity(Gravity.CENTER);LinearLayout.LayoutParams pr=new LinearLayout.LayoutParams(-1,-2);pr.topMargin=dp(14);root.addView(privacy,pr);
    }
    private interface Action{void run();}
    private TextView addPermissionRow(String title,String description,String action,Action callback){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(12),dp(14),dp(12));box.setBackground(shape(card,17));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.bottomMargin=dp(9);rows.addView(box,bp);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);box.addView(head,new LinearLayout.LayoutParams(-1,-2));TextView t=label(title,15,text);t.setTypeface(null,Typeface.BOLD);head.addView(t,new LinearLayout.LayoutParams(0,-2,1));TextView state=label("",11,green);head.addView(state);TextView desc=label(description,12,muted);desc.setLineSpacing(dp(2),1);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(4);box.addView(desc,dp1);Button b=button(action);LinearLayout.LayoutParams bp1=new LinearLayout.LayoutParams(-2,dp(38));bp1.gravity=Gravity.END;bp1.topMargin=dp(9);box.addView(b,bp1);b.setOnClickListener(v->callback.run());return state;
    }
    private boolean accessibilityEnabled(){String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);return enabled!=null&&enabled.toLowerCase().contains(getPackageName().toLowerCase()+"/"+ScreenTextAccessibilityService.class.getName().toLowerCase());}
    private void openAccessibility(){new AlertDialog.Builder(this).setTitle("Acessibilidade opcional").setMessage("O TecladoIA não precisa de acessibilidade para aparecer ou digitar. Ative o serviço somente se quiser usar “Analisar tela”. Quando ativado, a captura ocorre apenas depois de você tocar nessa função e confirmar.").setNegativeButton("Agora não",null).setPositiveButton("Abrir definições",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).show();}
    private void requestMic(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"Microfone permitido.",Toast.LENGTH_SHORT).show();refreshStatuses();}else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},12);}
    private void requestNotifications(){if(Build.VERSION.SDK_INT<33){Toast.makeText(this,"Este Android não pede permissão de notificações por app.",Toast.LENGTH_SHORT).show();refreshStatuses();return;}if(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED){refreshStatuses();return;}requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},13);}
    private void manageBattery(){if(Build.VERSION.SDK_INT<23){Toast.makeText(this,"Esta opção não existe nesta versão do Android.",Toast.LENGTH_SHORT).show();return;}PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);if(pm.isIgnoringBatteryOptimizations(getPackageName())){Toast.makeText(this,"Sem restrições de bateria já está ativo.",Toast.LENGTH_SHORT).show();refreshStatuses();return;}try{Intent i=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception ex){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}}
    private void refreshStatuses(){if(accessibilityState==null)return;accessibilityState.setText(accessibilityEnabled()?"Ativo":"Desligado");micState.setText(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"Permitido":"Não permitido");notificationState.setText(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"Permitidas":"Não permitidas");PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);batteryState.setText(Build.VERSION.SDK_INT<23||pm.isIgnoringBatteryOptimizations(getPackageName())?"Sem restrições":"Otimizada");}
    @Override protected void onResume(){super.onResume();refreshStatuses();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);refreshStatuses();}
}
