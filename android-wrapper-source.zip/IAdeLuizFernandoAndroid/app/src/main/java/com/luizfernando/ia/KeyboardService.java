package com.luizfernando.ia;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class KeyboardService extends InputMethodService {
    static KeyboardService instance;
    private SpeechRecognizer activeRecognizer;
    private final int ink=Color.rgb(22,27,45),tile=Color.rgb(249,249,255),purple=Color.rgb(113,91,232),surface=Color.rgb(225,229,243);
    private GradientDrawable shape(int c,int radius){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(fg);b.setAllCaps(false);b.setMinHeight(dp(44));b.setMinimumHeight(dp(44));b.setPadding(dp(3),0,dp(3),0);b.setBackground(shape(bg,13));return b;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER);return r;}
    @Override public void onCreate(){super.onCreate();instance=this;}
    @Override public void onDestroy(){destroyRecognizer(true);if(instance==this)instance=null;super.onDestroy();}
    @Override public void onWindowHidden(){destroyRecognizer(true);super.onWindowHidden();}
    private void destroyRecognizer(boolean cancel){SpeechRecognizer r=activeRecognizer;activeRecognizer=null;if(r!=null){try{if(cancel)r.cancel();}catch(Exception ignored){}try{r.destroy();}catch(Exception ignored){}}}
    private void restoreKeyboard(){destroyRecognizer(false);setInputView(onCreateInputView());}
    @Override public View onCreateInputView(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(5),dp(5),dp(5),dp(5));root.setBackground(shape(Color.rgb(237,239,248),16));
        LinearLayout top=row();TextView brand=new TextView(this);brand.setText("✦  TecladoIA");brand.setTextSize(16);brand.setTextColor(ink);brand.setTypeface(null,Typeface.BOLD);top.addView(brand,new LinearLayout.LayoutParams(0,dp(44),1));Button mic=button("🎙",surface,ink);top.addView(mic,new LinearLayout.LayoutParams(-2,dp(44)));Button analyze=button("Analisar tela",purple,Color.WHITE);top.addView(analyze,new LinearLayout.LayoutParams(-2,dp(44)));root.addView(top);mic.setOnClickListener(v->startDictation());analyze.setOnClickListener(v->requestScreenAnalysis());
        String[][] keys={{"q","w","e","r","t","y","u","i","o","p"},{"a","s","d","f","g","h","j","k","l"},{"⇧","z","x","c","v","b","n","m","⌫"}};
        for(String[] line:keys){LinearLayout r=row();for(String k:line)addKey(r,k,k,1,"⇧".equals(k)||"⌫".equals(k));root.addView(r);}
        LinearLayout last=row();addKey(last,"?123","?123",2,true);addKey(last,"😊","😊",1,true);addKey(last,"English"," ",5,false);addKey(last,". ",". ",1,true);addKey(last,"↵","ENTER",2,true);root.addView(last);
        TextView hint=new TextView(this);hint.setText("O teclado não registra o que você digita. Análise de tela é opcional.");hint.setTextSize(10);hint.setTextColor(Color.rgb(86,96,121));hint.setGravity(Gravity.CENTER);root.addView(hint,new LinearLayout.LayoutParams(-1,dp(27)));return root;
    }
    private void addKey(LinearLayout r,String label,String value,int weight,boolean special){Button b=button(label,special?surface:tile,ink);b.setTypeface(null,Typeface.BOLD);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),weight);p.setMargins(dp(2),dp(3),dp(2),dp(3));r.addView(b,p);b.setOnClickListener(v->{InputConnection ic=getCurrentInputConnection();if(ic==null)return;if("⌫".equals(value))ic.deleteSurroundingText(1,0);else if("ENTER".equals(value))ic.commitText("\n",1);else if(!"⇧".equals(value))ic.commitText(value,1);});}
    private void startDictation(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"Permita o microfone nas definições do TecladoIA antes de ditar.",Toast.LENGTH_LONG).show();return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){Toast.makeText(this,"O reconhecimento de voz não está disponível neste dispositivo.",Toast.LENGTH_LONG).show();return;}
        destroyRecognizer(true);
        final SpeechRecognizer recognizer=SpeechRecognizer.createSpeechRecognizer(this);activeRecognizer=recognizer;
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(16),dp(14),dp(16),dp(14));panel.setBackground(shape(Color.rgb(237,239,248),16));TextView notice=new TextView(this);notice.setText("Microfone ativo só enquanto este ditado estiver aberto. Fale agora ou toque em Concluir.");notice.setTextColor(ink);notice.setTextSize(14);notice.setGravity(Gravity.CENTER);panel.addView(notice,new LinearLayout.LayoutParams(-1,dp(48)));LinearLayout actions=row();Button stop=button("Concluir",purple,Color.WHITE),cancel=button("Cancelar",surface,ink);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(stop,new LinearLayout.LayoutParams(0,dp(44),1));panel.addView(actions);setInputView(panel);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){notice.setText("Ouvindo… fale agora.");}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){notice.setText("Processando fala…");}
            public void onError(int e){if(activeRecognizer!=recognizer)return;destroyRecognizer(false);notice.setText("Ditado encerrado. Toque em Cancelar para voltar ao teclado e tente novamente.");}
            public void onResults(Bundle b){if(activeRecognizer!=recognizer)return;ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(results!=null&&!results.isEmpty()){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(results.get(0),1);}destroyRecognizer(false);setInputView(onCreateInputView());}
            public void onPartialResults(Bundle b){ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(activeRecognizer==recognizer&&results!=null&&!results.isEmpty())notice.setText(results.get(0));}public void onEvent(int e,Bundle b){}
        });
        Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");
        try{recognizer.startListening(intent);}catch(RuntimeException ex){destroyRecognizer(false);notice.setText("Não foi possível iniciar o ditado neste dispositivo.");}
        stop.setOnClickListener(v->{if(activeRecognizer==recognizer){notice.setText("Parando ditado…");try{recognizer.stopListening();}catch(RuntimeException ex){restoreKeyboard();}}});cancel.setOnClickListener(v->{if(activeRecognizer==recognizer)restoreKeyboard();else setInputView(onCreateInputView());});
    }
    private void requestScreenAnalysis(){
        if(!ScreenTextAccessibilityService.isActive()){Toast.makeText(this,"Ative o serviço de acessibilidade opcional para analisar a tela.",Toast.LENGTH_LONG).show();Intent i=new Intent(this,AccessibilitySetupActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);return;}
        LinearLayout consent=new LinearLayout(this);consent.setOrientation(1);consent.setPadding(dp(12),dp(12),dp(12),dp(12));consent.setBackground(shape(Color.rgb(237,239,248),16));TextView msg=new TextView(this);msg.setText("ANALISAR TELA?\n\nO teclado vai ler o texto visível no aplicativo atual; senhas são ignoradas. Nada será enviado até você revisar e confirmar.");msg.setTextColor(ink);msg.setTextSize(14);msg.setPadding(dp(8),dp(4),dp(8),dp(12));consent.addView(msg);LinearLayout actions=row();Button cancel=button("Cancelar",surface,ink),capture=button("Capturar texto",purple,Color.WHITE);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(46),1));actions.addView(capture,new LinearLayout.LayoutParams(0,dp(46),1));consent.addView(actions);setInputView(consent);cancel.setOnClickListener(v->setInputView(onCreateInputView()));capture.setOnClickListener(v->{String text=ScreenTextAccessibilityService.captureVisibleText();if(text==null||text.trim().isEmpty()){Toast.makeText(this,"Não encontrei texto legível.",Toast.LENGTH_LONG).show();setInputView(onCreateInputView());return;}Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra(MainActivity.EXTRA_SCREEN_TEXT,text);startActivity(i);});
    }
    @Override public void onStartInputView(EditorInfo info,boolean restarting){super.onStartInputView(info,restarting);}
}
