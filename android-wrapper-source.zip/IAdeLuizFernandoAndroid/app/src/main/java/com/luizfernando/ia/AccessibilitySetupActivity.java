package com.luizfernando.ia;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AccessibilitySetupActivity extends Activity {
  private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(16,19,34));getWindow().setNavigationBarColor(Color.rgb(16,19,34));
    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(24),dp(32),dp(24),dp(24));root.setGravity(Gravity.CENTER_VERTICAL);root.setBackgroundColor(Color.rgb(16,19,34));
    TextView title=new TextView(this);title.setText("Analisar texto da tela");title.setTextColor(Color.WHITE);title.setTextSize(24);title.setTypeface(null,Typeface.BOLD);root.addView(title);
    TextView desc=new TextView(this);desc.setText("Para usar esta função, o Android pede que você ative o serviço de acessibilidade do TecladoIA. O serviço fica desligado até você ativá-lo.\n\nQuando ativado, ele só captura o texto da tela após você tocar em “Analisar tela” no teclado. Esse texto será enviado ao Gemini usando sua chave API para você perguntar algo sobre ele.\n\nNão coletamos texto em segundo plano, senhas, campos de senha ou conteúdo sem a sua ação. Você pode desligar o serviço a qualquer momento nas configurações de Acessibilidade do Android.");desc.setTextColor(Color.rgb(208,214,232));desc.setTextSize(15);desc.setLineSpacing(dp(4),1f);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(18);root.addView(desc,dp1);
    Button proceed=new Button(this);proceed.setText("Abrir configurações de acessibilidade");proceed.setAllCaps(false);proceed.setTextSize(15);proceed.setTextColor(Color.WHITE);proceed.setBackground(bg(Color.rgb(113,91,232)));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(54));bp.topMargin=dp(28);root.addView(proceed,bp);proceed.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    Button cancel=new Button(this);cancel.setText("Agora não");cancel.setAllCaps(false);cancel.setTextColor(Color.rgb(207,211,228));cancel.setBackgroundColor(Color.TRANSPARENT);root.addView(cancel,new LinearLayout.LayoutParams(-1,dp(48)));cancel.setOnClickListener(v->finish());setContentView(root);
  }
  private GradientDrawable bg(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(15));return d;}
}
