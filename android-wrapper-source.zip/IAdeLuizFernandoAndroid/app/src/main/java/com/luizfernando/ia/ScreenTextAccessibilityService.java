package com.luizfernando.ia;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

public class ScreenTextAccessibilityService extends AccessibilityService {
    private static volatile ScreenTextAccessibilityService active;
    public static boolean isActive(){ return active != null; }
    @Override protected void onServiceConnected(){ super.onServiceConnected(); active=this; }
    @Override public void onDestroy(){ if(active==this)active=null; super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){ /* Intentionally do not read event text or collect in background. */ }
    @Override public void onInterrupt(){}

    public static boolean captureVisibleText(){
        ScreenTextAccessibilityService s=active;
        if(s==null || KeyboardService.instance==null)return false;
        AccessibilityNodeInfo root=null;
        for(AccessibilityWindowInfo window:s.getWindows()){
            if(window!=null && window.getType()==AccessibilityWindowInfo.TYPE_APPLICATION){
                AccessibilityNodeInfo candidate=window.getRoot();
                if(candidate!=null){root=candidate;break;}
            }
        }
        if(root==null)return false;
        StringBuilder out=new StringBuilder();
        try{collect(root,out,0);}finally{root.recycle();}
        String text=out.toString().trim();
        if(text.isEmpty())return false;
        if(text.length()>6000)text=text.substring(0,6000);
        KeyboardService.injectText(text);
        return true;
    }
    private static void collect(AccessibilityNodeInfo node,StringBuilder out,int depth){
        if(node==null||depth>35||out.length()>=6000)return;
        if(node.isPassword())return;
        CharSequence t=node.getText();
        if(t!=null){String v=t.toString().trim();if(!v.isEmpty()&&!v.equals("TecladoIA")&&!v.equals("Analisar tela")){if(out.length()>0)out.append('\n');out.append(v);}}
        CharSequence d=node.getContentDescription();
        if(d!=null){String v=d.toString().trim();if(!v.isEmpty()&&!v.equals("TecladoIA")){if(out.length()>0)out.append('\n');out.append(v);}}
        for(int i=0;i<node.getChildCount()&&out.length()<6000;i++){AccessibilityNodeInfo c=node.getChild(i);if(c!=null){collect(c,out,depth+1);c.recycle();}}
    }
}
