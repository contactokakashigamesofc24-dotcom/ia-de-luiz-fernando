# IA de Luiz Fernando para Android

WebView wrapper para a aplicação hospedada em HTTPS no GitHub Pages. O APK não contém a chave Gemini: o usuário informa a chave dentro da aplicação. O microfone só é concedido ao domínio HTTPS oficial do app e após a permissão Android.

O workflow GitHub Actions em `.github/workflows/build-apk.yml` compila um APK de debug e publica-o como ativo numa GitHub Release.

> O APK de debug serve para instalação/testes. Não é uma build assinada para publicação na Google Play.
